#create a angular application of employee management where attributes are 
Employee:{employeeid:string,empname:string,empemail:string(validation required),salary:double,department:string}

#create method post , get , get with employeeid , create components, employee form, employee list.

#create employee service . call json server for backend

#use ngOnit lifecycle hooks and use observable to

use angular 15