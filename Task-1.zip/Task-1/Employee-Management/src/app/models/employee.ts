export interface Employee{
    id?:string,
    employeeid:string,
    empname:string,
    empemail:string,
    salary:number,
    department:string
}