import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { Employee } from '../models/employee';


@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employee:Employee[]=[]
  searchId:string=''
  foundEmployee?:Employee;
  errorMessage:string=''

  constructor(private service:EmployeeService){}

  ngOnInit(): void {
    this.service.getAll().subscribe((data)=>this.employee=data);
  }
  
getById(){
  this.service.getById(this.searchId).subscribe({
    next:(emp)=>{
      this.foundEmployee=emp;
      this.errorMessage=''
    },
    error:()=>{
      this.foundEmployee=undefined;
      this.errorMessage='Employee not Found'
    }
  })
}

}
