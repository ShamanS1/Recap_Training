import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { EmployeeService } from '../services/employee.service';
import { Employee } from '../models/employee';


@Component({
  selector: 'app-employee-form',
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css']
})
export class EmployeeFormComponent {
constructor(private fb:FormBuilder,private empService:EmployeeService){}

empForm= this.fb.group({
  employeeid:[''],
  empname:[''],
  empemail:['',[Validators.required,Validators.email]],
  salary:[0],
  department:['']
})

onSubmit(){
  if(this.empForm.valid){
    const newEmp = this.empForm.value as Employee
    this.empService.addEmployee(newEmp).subscribe(()=>{
       alert("employee added")
    this.empForm.reset()}
)
   
  }
}

onDelete(){
  const empId = this.empForm.get("employeeid")?.value;
  if(empId){
    this.empService.deleteEmployee(empId).subscribe(()=>{
      alert("Employee deleted");
      this.empForm.reset();
    })
  }else{
    alert("not a valid id")
  }
}

onUpdate(){
if(this.empForm.valid){
  const empUpdate = this.empForm.value as Employee
  const newEmp = {...empUpdate,id:empUpdate.employeeid}
  this.empService.updateEmployee(newEmp).subscribe(()=>{
    alert("Employee updated")
    this.empForm.reset();
  })
}
}
}
